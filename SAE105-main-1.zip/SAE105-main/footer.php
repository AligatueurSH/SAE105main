<div class="grid-container">
    <!-- other elements -->
    <footer>
        <a href="references.php" class="references-link">Références</a>
        <p> &copy; MMI Troyes</p> 
        <p> <strong>El Kolei Félicien 2023</strong> </p>
    </footer>
</div>